<x-layout-admin>
    ggfd
</x-layout-admin>