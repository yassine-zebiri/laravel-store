<x-layout :pageTitle="$namePage">
    @include('partails._hero')
@php
   // print_r($sliders);
@endphp
    @if (count($sliders))
        <x-slider :data="$sliders"/>
    @endif
    
    <x-card-content >

        <div class="row w-100  justify-content-center g-0 row-gap-3">
            <div class="col-12">
                <h3>أقسام المتجر</h3>
            </div>
            @foreach ($categories as $item)
                <x-card-categorie :item='$item' />
            @endforeach
        </div>


        <div class="row w-100 align-items-stretch  justify-content-start g-0 row-gap-3" dir="rtl">
            <h3>الأكثر مبيعا</h3>
            @foreach ($products as $item)   
                <x-card-product :item="$item"  />
            @endforeach
        </div>

        @foreach ($rows as $row)
        @if (count($row->products)>0)
            <div class="row w-100 align-items-stretch 
                justify-content-start g-0 row-gap-3 mt-3" dir="rtl">
                <h3>{{$row->title}}</h3>
                @foreach ($row->products as $item)   
                    <x-card-product :item="$item"  />
                @endforeach
            </div>
        @endif
        @endforeach




    </x-card-content>
</x-layout>