<main class=" container mt-5">
    {{$slot}}
</main>