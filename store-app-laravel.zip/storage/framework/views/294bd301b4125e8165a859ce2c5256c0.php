<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['data']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['data']); ?>
<?php foreach (array_filter((['data']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<div id="carouselExampleInterval" class="carousel slide" data-bs-ride="carousel">
    <div class="carousel-indicators">
        <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
        <?php for($i = 1; $i < count($data); $i++): ?>
            <button type="button" data-bs-target="#carouselExampleIndicators" 
            data-bs-slide-to="<?php echo e($i); ?>" aria-label="Slide <?php echo e($i+1); ?>"></button>
        <?php endfor; ?>
    </div>

    <div class="carousel-inner">
        <div class="carousel-item active" data-bs-interval="3000">
            <a href="/slider/<?php echo e($data[0]->id); ?>">
                <img src="<?php echo e(asset('/storage/'.$data[0]->pic_slider)); ?>" class="d-block w-100" alt="...">
            </a>
        </div>
        <?php for($i = 1; $i < count($data); $i++): ?>
            <div class="carousel-item " data-bs-interval="3000">
                <a href="/slider/<?php echo e($data[$i]->id); ?>">
                    <img src="<?php echo e(asset('/storage/'.$data[$i]->pic_slider)); ?>" class="d-block w-100" alt="...">
                </a>
            </div>
        <?php endfor; ?>
    </div>

    <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleInterval" data-bs-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Previous</span>
    </button>
    <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleInterval" data-bs-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Next</span>
    </button>

</div><?php /**PATH C:\Users\DJELFA SHOP\store-app-laravel\resources\views/components/slider.blade.php ENDPATH**/ ?>