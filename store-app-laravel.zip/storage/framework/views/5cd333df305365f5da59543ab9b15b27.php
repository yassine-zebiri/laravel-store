<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['item']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['item']); ?>
<?php foreach (array_filter((['item']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<div class="col-lg-3 col-md-4 col-sm-6 col-6 p-1">
    <div class="card h-100">
        <div  class="h-100 d-flex flex-column justify-content-between text-decoration-none text-black" >
        <a href="/product/<?php echo e($item->id); ?>">
            <img class=" card-img-top" width="100%" src="<?php echo e(asset('/storage/'.$item->pic)); ?>" alt="" srcset="">
        </a>
        <div class="card-body d-flex flex-column justify-content-between">
            <a href="" class="text-decoration-none text-black pb-2">
                <p class="card-title"><?php echo e($item->name); ?> </p>
                <p class="card-text"><?php echo e($item->price); ?> د.ج</p>
            </a>
            <button class="btn btn-primary w-100" @click="addToCart({
                id:<?php echo e($item->id); ?>,
                name:'<?php echo e($item->name); ?>',
                price:<?php echo e($item->price); ?>,
                pic:'<?php echo e(asset('/storage/'.$item->pic)); ?>',
                quantity:1
                })">
                <i class="fa-solid fa-cart-plus mx-1"></i>
                اضافة للسلة</button>
        </div>
        </div>
    </div>
</div>

<?php /**PATH C:\Users\DJELFA SHOP\store-app-laravel\resources\views/components/card-product.blade.php ENDPATH**/ ?>