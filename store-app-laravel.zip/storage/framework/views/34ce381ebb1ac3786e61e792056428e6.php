<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['data','name']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['data','name']); ?>
<?php foreach (array_filter((['data','name']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
 <!-- breadcrumb         ------------------------------------------->
 <nav aria-label="breadcrumb" >
    <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="/">الصفحة الرئيسية</a></li>
        <li class="breadcrumb-item">
            <a href="/show/filter/?categories%5B<?php echo e($data->id); ?>%5D=<?php echo e($data->id); ?>">
                <?php echo e($data->name); ?>

            </a>
        </li>
        <li class="breadcrumb-item active" aria-current="page"><?php echo e($name); ?></li>
    </ol>
</nav>
<!-- end breadcrumb         -------------------------------------------><?php /**PATH C:\Users\DJELFA SHOP\store-app-laravel\resources\views/components/breadcrumb.blade.php ENDPATH**/ ?>