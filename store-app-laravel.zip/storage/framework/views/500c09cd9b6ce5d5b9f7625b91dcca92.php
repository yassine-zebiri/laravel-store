<?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout-admin','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layout-admin'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php if(session()->has('message')): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <span><?php echo e(session('message')); ?></span>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    <?php endif; ?>
    <div class="p-5">
        <form method="post" action="/admin/products/categories/create" class="row row-gap-4 w-100 bg-white border p-4 rounded" 
        enctype="multipart/form-data" >
        <?php echo csrf_field(); ?>
            <div class="col-6">
                <label class="form-label" for="">اسم الفئة</label>
                <input name="name" class="form-control form-control-lg" type="text">
            </div>
            
            <div class="col-6">
                <label class="form-label" for="">رفع صورة الفئة</label>
                <input name="pic" type="file" class="form-control form-control-lg" aria-label="file example" required>
                <div class="invalid-feedback">Example invalid form file feedback</div>
            </div>
            
            <div>
                <button class="btn btn-primary" type="submit">اضافة منتج</button>
            </div>
        </form>
    </div>

    <div class="px-5">
        <h3>الفئات :</h3>
        <table class="table bg-white">
            <thead>
                <tr>
                    <td>
                        <span>معرف id</span>
                    </td>
                    <td>
                        <span>اسم الفئة</span>
                    </td>
                    <td>
                        <span>حذف</span>
                    </td>
                </tr>
            </thead>
            <tbody>
            <?php if(count($categories)>0): ?>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>
                            #<?php echo e($item->id); ?>

                        </td>
                        <td><img src="<?php echo e(asset('/storage/'.$item->path_pic)); ?>" width="75" alt="" srcset="">
                            <span class=""><?php echo e($item->name); ?> </span>
                        </td>
                        <td>
                            <div class=" d-flex align-items-center gap-3">
                                <a class="btn btn-primary" href="/admin/products/categories/<?php echo e($item->id); ?>">تعديل</a>
                                <form action="/admin/products/categories/<?php echo e($item->id); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-danger">خذف</button>
                                </form>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                <tr>
                    <td class="w-100">
                    <div class="text-center p-3 bg-white">
                        لا يوجد فئات
                    </div></td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?><?php /**PATH C:\Users\DJELFA SHOP\store-app-laravel\resources\views/admin/tools-categories.blade.php ENDPATH**/ ?>