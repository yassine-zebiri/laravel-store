<?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout-admin','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layout-admin'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.flash-message','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('flash-message'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
    <div >
        
        <form method="post" action="/admin/ui-store/tools-slider/create" 
        class="row row-gap-4 w-100 bg-white border p-4 rounded" enctype="multipart/form-data" >
            <?php echo csrf_field(); ?>
            <div class="col-6">
                <label class="form-label" for="">رفع صورة الشريحة</label>
                <input name="pic" accept="image/*" type="file" class="form-control form-control-lg" aria-label="file example" required>
            </div>
            
            <div>
                <button class="btn btn-primary" type="submit">اضافة شريحة</button>
            </div>
        </form>
    </div>

    <div class="row pt-3 row-gap-5">
        <h3>الشرائح :</h3>
        
       
        <?php for($i = 0; $i < count($sliders); $i++): ?>
        <div  class="col-6">
            <div class=" bg-white rounded">
                <div class="d-flex justify-content-between align-items-center
                px-3 py-1 ">
                    <div>
                        <p>شريحة رقم : <?php echo e($i+1); ?></p>
                        <p>عدد العناصر : <?php echo e(count(App\Models\Sliders::with('products')->find($sliders[$i]->id)->products)); ?></p>
                    </div>
                    <div class=" d-flex align-content-center gap-3">
                        <a href="/admin/ui-store/tools-slider/edit/<?php echo e($sliders[$i]->id); ?>" class="btn btn-outline-dark">
                            <i class="fa-solid fa-pen"></i>
                        </a>
                        <form method="POST" action="/admin/ui-store/tools-slider/slider/<?php echo e($sliders[$i]->id); ?>">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button class="btn btn-outline-danger">
                                <i class="fa-solid fa-trash"></i>
                            </button>
                        </form>
                    </div>
                </div>
                <div>
                    <img class="w-100" src="<?php echo e(asset('/storage/'.$sliders[$i]->pic_slider)); ?>" alt="" srcset="">
                </div>
            </div>
        </div>
        <?php endfor; ?>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?><?php /**PATH C:\Users\DJELFA SHOP\store-app-laravel\resources\views/admin/slider/tools-sliders.blade.php ENDPATH**/ ?>