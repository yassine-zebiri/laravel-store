<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="/admin/style.css">

    
    <!-- CSS bootstrap -->

    <link rel="stylesheet" href="<?php echo e(URL::asset('css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::asset('css/main.css')); ?>">

    <script src="https://kit.fontawesome.com/e005db6dde.js" crossorigin="anonymous"></script>
</head>

<body class="bg-light" dir="rtl">
    <main class="container-fluid  pt-5">

        <form method="POST" action="/users/authenticate" 
        class="form m-auto w-100 border rounded p-4 bg-white" style="max-width: 450px;">
            <?php echo csrf_field(); ?>
            <h2 class="text-center mt-3">تسجيل الدخول</h2>

            <div class="form-group mt-3">
                <label  class="form-label" for="">ايميل</label>
                <div class="input-group flex-nowrap" dir="ltr">
                    <span class="input-group-text">@</span>
                    <input name="email" placeholder="ادخل البريد الالكتروني"  class="form-control" type="email">
                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-red-500"> <?php echo e($message); ?> </p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                
            </div>

            <div class="form-group mt-3">
                <label class="form-label" for="">كلمو السر</label>
                <input name="password" class="form-control" placeholder="كلمة السر" type="password">
                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-red-500"> <?php echo e($message); ?> </p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="mt-3">
                <button class="btn btn-primary">تسجي الدخول</button>
            </div>
            
        </form>
    </main>
<!-- script js bootstrap -->
<script src="<?php echo e(URL::asset('js/bootstrap.bundle.min.js')); ?>"></script>

</body>
</html><?php /**PATH C:\Users\DJELFA SHOP\store-app-laravel\resources\views/admin/auth/log-in.blade.php ENDPATH**/ ?>