<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['item']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['item']); ?>
<?php foreach (array_filter((['item']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<div class="col-lg-4 col-12 px-2">
    <a href="/show/filter/?categories%5B<?php echo e($item->id); ?>%5D=<?php echo e($item->id); ?>" class="text-black text-decoration-none">
        <div class="text-center">
            <img class="w-100 rounded" src="<?php echo e(asset('/storage/'.$item->path_pic)); ?>" alt="" srcset="">
            <p class="pt-2"><?php echo e($item->name); ?></p>
        </div>
    </a>
</div><?php /**PATH C:\Users\DJELFA SHOP\store-app-laravel\resources\views/components/card-categorie.blade.php ENDPATH**/ ?>