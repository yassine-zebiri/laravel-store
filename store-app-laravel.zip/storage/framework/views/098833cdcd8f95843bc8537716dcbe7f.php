<?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout-admin','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layout-admin'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php if(session()->has('message')): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <span><?php echo e(session('message')); ?></span>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    <?php endif; ?>
    <div class="p-5">
        <form method="post" action="/admin/products/categories/<?php echo e($categorie->id); ?>" class="row row-gap-4 w-100 bg-white border p-4 rounded" 
        enctype="multipart/form-data" >
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <?php if($categorie->path_pic): ?>
            <div class="col-12">
                <img src="<?php echo e(asset('/storage/'.$categorie->path_pic)); ?>" width="100%" alt="">
            </div>
        <?php else: ?>
            <div class="col-12 textt-center">
                لا توجد صورة
            </div>
        <?php endif; ?>
            <div class="col-6">
                <label class="form-label" for="">اسم الفئة</label>
                <input value="<?php echo e($categorie->name); ?>" name="name" class="form-control form-control-lg" type="text">
            </div>
            
            <div class="col-6">
                <label class="form-label" for="">رفع صورة الفئة</label>
                <input name="pic" type="file" class="form-control form-control-lg" aria-label="file example" >
                <div class="invalid-feedback">Example invalid form file feedback</div>
            </div>
            
            <div>
                <button class="btn btn-primary" type="submit">تحديث منتج</button>
            </div>
        </form>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?><?php /**PATH C:\Users\DJELFA SHOP\store-app-laravel\resources\views/admin/edit-categorie.blade.php ENDPATH**/ ?>