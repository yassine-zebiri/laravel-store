<?php
 $id=$_GET['id'];   
?>
<ul class="list-group">
<?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<li class=" list-group-item d-flex justify-content-between">
    <div>
        <span class="mx-3" style="color: gray"><?php echo e($item->id); ?>#</span>
        <span class="mx-3"><?php echo e($item->name); ?></span>
    </div>
    <form action="/admin/ui-store/tools-row/edit/card/<?php echo e($id); ?>/<?php echo e($item->id); ?>" method="post">
        <?php echo csrf_field(); ?>
        <button class="btn btn-primary">اضافة</button>
    </form>
</li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul><?php /**PATH C:\Users\DJELFA SHOP\store-app-laravel\resources\views/admin/rows/serach.blade.php ENDPATH**/ ?>