<?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => ['pageTitle' => $namePage]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['pageTitle' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($namePage)]); ?>
    <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.card-content','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('card-content'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    
    <div class="row">
    
    
        <div class="col-lg-3 col-12 p-3">
            <div class="bg-white p-3">
                <h1>تصفيت النتائج</h1>
                <div>
                    
                    <form action="/show/filter" method="get">
                        <?php echo csrf_field(); ?>
    
                        <div>
                            <p class="p-0 m-0">الفئات :</p>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class=" input-group justify-content-between">
                                    <label class="form-label" for=""><?php echo e($item->name); ?> </label>
                                    <input class=" form-check mx-2" type="checkbox" 
                                    name="categories[<?php echo e($item->id); ?>]"
                                    value="<?php echo e($item->id); ?>"
                                    <?php
                                    if(isset($_REQUEST['categories'])){
                                        foreach ($_REQUEST['categories'] as $value) {
                                            # code...
                                            if($value == $item->id){
                                                echo 'checked';
                                            }
                                        }};
                                    ?>
                                    
                                    >
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <hr/>
                        <div>
                            <p class="p-0 m-0">السعر:</p>
                            <div class=" input-group mt-2">
                                <label class=" form-label" for="">أعلى سعر</label>
                                <input class=" form-control-sm w-50 mx-2" type="number" name="max-price"
                                    max="<?php echo e($max_price); ?>"
                                    min="<?php echo e($min_price); ?>"
                                <?php
                                    
                                
                                if(isset($_REQUEST['max-price']) && !empty($_REQUEST['max-price'])){
                                    echo 'value='.$_REQUEST['max-price'];
                                }else{
                                    echo 'value='.$max_price;
                                }
                                ?>
                                >
                            </div>
                            <div  class=" input-group mt-2">
                                <label class=" form-label"  for="">أدنى سعر</label>
                                
                                <input class=" form-control-sm w-50 mx-2" type="number" name="min-price"
                                    max="<?php echo e($max_price); ?>"
                                    min="<?php echo e($min_price); ?>"
                                <?php
                                    
                                
                                if(isset($_REQUEST['max-price']) && !empty($_REQUEST['max-price'])){
                                    echo 'value='.$_REQUEST['min-price'];
                                }else{
                                    echo 'value='.$min_price;
                                }
                                ?>
                                >
                            </div>
                        </div>
                        <hr/>
                        <div class="w-100 mt-3">
                            <button class="btn btn-primary mx-2" type="submit">تطبيق</button>
                            <a href="/show/filter" class="btn btn-outline-primary mx-2" type="reset">اعادة ضبط</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    
    
        <div class="col-lg-9  col-12 pt-3">
            <div class="row">
    
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                    
                    <div class="col-lg-3 col-md-4  col-sm-6 col-6 p-1">
                        <div class="card">
                            <a href="/product/<?php echo e($item->id); ?>" class=" text-decoration-none text-black" >
                            <img class=" card-img-top" width="100%" src="<?php echo e(asset('/storage/'.$item->pic)); ?>" alt="" srcset="">
                            <div class="card-body">
                                <p class="card-title"><?php echo e($item->name); ?></p>
                                <p class="card-text"><?php echo e($item->price); ?> د.ج</p>
                                <button class="btn btn-primary w-100"><i class="fa-solid fa-cart-plus mx-1"></i>
                                    اضافة للسلة</button>
                            </div></a>
                        </div>
                    </div>
    
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
                
    
            </div>
        </div>
    </div>
    
    
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
    
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?><?php /**PATH C:\Users\DJELFA SHOP\store-app-laravel\resources\views/store/filter.blade.php ENDPATH**/ ?>