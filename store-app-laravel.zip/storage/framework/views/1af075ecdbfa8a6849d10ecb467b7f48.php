<!-- breadcrumb         ------------------------------------------->
<nav aria-label="breadcrumb" >
    <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="/">الصفحة الرئيسية</a></li>
        <li class="breadcrumb-item active" aria-current="page"><a >نظارات للرجال</a></li>
    </ol>
</nav>
<!-- end breadcrumb         -------------------------------------------><?php /**PATH C:\Users\DJELFA SHOP\store-app-laravel\resources\views/partails/_breadcrumb.blade.php ENDPATH**/ ?>