<?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout-admin','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layout-admin'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.flash-message','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('flash-message'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
    <div class="w-100 ">
        <div class="bg-white p-3 rounded">
        <img class=" m-auto d-block w-100" src="<?php echo e(asset('/storage/'.$slider->pic_slider)); ?>" alt="" srcset=""> 
        <div >
            <form method="post" action="/admin/ui-store/tools-slider/slider/<?php echo e($slider->id); ?>" 
            class="row row-gap-4 w-100 bg-white" enctype="multipart/form-data" >
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="col-6">
                    <label class="form-label" for="">رفع صورة الشريحة</label>
                    <input name="pic" accept="image/*" type="file" class="form-control form-control-lg" aria-label="file example" required>
                </div>
                <div>
                    <button class="btn btn-primary" type="submit">تحديث صورة شريحة</button>
                </div>
            </form>
        </div>
    </div> 

    <div class="py-3">
        <?php echo $__env->make('admin.slider._serach', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>


    
    <div class="py-3">
        <div class="p-3 rounded bg-white">
            <h5>المنتجات التي تم اضافتها :</h5>

            <div class="row align-items-stretch column-g ap-1">
                <?php if(count($products)>0): ?>
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-3 rounded border p-0">
                            <div class="  ">
                                <div class="p-3">
                                    <form action="/admin/ui-store/tools-slider/edit/card/<?php echo e($slider->id); ?>/<?php echo e($item->id); ?>" method="post">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button class="btn btn-outline-dark">
                                            <i class="fa-solid fa-trash"></i>
                                        </button>
                                    </form>
                                </div>
                                <img width="100%" class="p-0" src="<?php echo e(asset('/storage/'.$item->pic)); ?>" alt="" srcset="">
                                <div class="p-3 text-center">
                                    <div>
                                        <?php echo e($item->name); ?>

                                    </div>
                                    <div><?php echo e($item->price); ?> د.ج</div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <div class="p-5 text-center">
                        لا توجد منتوجات
                    </div>
                <?php endif; ?>


            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?><?php /**PATH C:\Users\DJELFA SHOP\store-app-laravel\resources\views/admin/slider/edit-slider.blade.php ENDPATH**/ ?>