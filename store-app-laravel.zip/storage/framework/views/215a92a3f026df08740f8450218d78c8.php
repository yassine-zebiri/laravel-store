<?php if(session()->has('message')): ?>
<div class="alert alert-success alert-dismissible fade show" role="alert">
    <span><?php echo e(session('message')); ?></span>
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
<?php endif; ?><?php /**PATH C:\Users\DJELFA SHOP\store-app-laravel\resources\views/components/flash-message.blade.php ENDPATH**/ ?>