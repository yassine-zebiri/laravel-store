<main class=" container mt-5">
    <?php echo e($slot); ?>

</main><?php /**PATH C:\Users\DJELFA SHOP\store-app-laravel\resources\views/components/card-content.blade.php ENDPATH**/ ?>